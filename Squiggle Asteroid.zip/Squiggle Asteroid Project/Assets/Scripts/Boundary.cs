﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boundary : MonoBehaviour
{
    public PlayerController playerController;

    //Create the action where any object who tries to exit the perimeter will be destroyed
    private void OnTriggerExit(Collider other)
    {
        Destroy(other.gameObject);

        //If the player is destroyed, then the score stops
        if (playerController == null) 
        { 
        return; 
        }
        Score.scoreValue += 1; //Every object(rocket) which is destroyed means 1 point
    }
    
}
