﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RocketMovement : MonoBehaviour
{
    //Make the game object(rocket) to move on the Y axis with a certain amount of speedness in a certain amount of time
    private float RocketSpeed = -10.0f;
    private void Update()
    {
        transform.Translate(0, Time.deltaTime * RocketSpeed, 0);
    }
}