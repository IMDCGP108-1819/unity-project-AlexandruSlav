﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundScroll : MonoBehaviour
{
    public float ScrollSpeed = 0.25f;
    public float tileSize = 7.0f;
    private float _timer = 0.0f;
    private Vector3 startPosition;

    private void Start()
    {
        startPosition = transform.position; //The deafult position of the background
    }

    private void Update() 
    { 
    //Make the background scroll down with a certain speed in a certain time
        _timer += Time.deltaTime;
        float newPosition = Mathf.Repeat(_timer * ScrollSpeed, tileSize);
        transform.position = startPosition + Vector3.down * newPosition;
    }
}