﻿using System;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public static int scoreValue = 0; //The score starts counting from 0
    Text score;

    private void Start()
    { 
    //Put the text on the screen
        score = GetComponent<Text>();
    }

    private void Update()
    { 
        //If the player presses the "R" button, then the score resets
        if (Input.GetKey(KeyCode.R))
        {
            scoreValue = 0;
        }

        score.text = "Score: " + scoreValue; //The text on the screen will be "Score:x", the "x" is the score of the player
    }
}