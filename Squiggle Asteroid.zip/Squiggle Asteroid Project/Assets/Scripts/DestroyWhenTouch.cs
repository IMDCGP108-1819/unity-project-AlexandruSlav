﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyWhenTouch : MonoBehaviour
{
    //If the game object(rocket) touches the other game object(asteroid), then both of them will be destroyed
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Boundary")//If the game object(rocket) touches the game object(boundry), then nothing will happen
        {
            return;
        }
            Destroy(other.gameObject);
            Destroy(gameObject);
    }
}