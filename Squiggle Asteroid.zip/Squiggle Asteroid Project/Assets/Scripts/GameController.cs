﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public GameObject rocket;
    private Vector3 spawnValue;
    private int rocketCount = 1000000000;
    private float spawnWait = 0.40f;
    private float restart = 1000000000;
    public PlayerController playerController;

    private void Start()
    {
        //Create the rocket spawn
            StartCoroutine(Spawn());

            IEnumerator Spawn()
            {
                for (int i = 0; i < rocketCount; i++)
                {
                    Vector3 spawnPosition = new Vector3(Random.Range(-2.78f, 2.86f), 9.0f, 0.0f); //The position where the rockets can spawn
                    Quaternion spawnRotation = Quaternion.identity; //The rotation of the rocket(none)
                    Instantiate(rocket, spawnPosition, spawnRotation); //Create the game object(rocket), the location and the rotation of it
                    yield return new WaitForSeconds(spawnWait); //Create time before another rocket spawns
                }
                yield return new WaitForSeconds(restart); //Create the next waves which will come after the first one finishes
            }
        }

    private void Update()
    {
        //If the player(asteroid) is destroyed, then the rockets will not spawn anymore
        if (playerController == null)
        {
            rocketCount = 0;
        }
    }
}