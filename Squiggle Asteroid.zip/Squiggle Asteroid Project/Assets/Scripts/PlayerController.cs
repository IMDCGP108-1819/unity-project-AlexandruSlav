﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.XR;

public class PlayerController : MonoBehaviour
{
    private Vector3 _target;
    public Camera Camera;
    public bool FollowMouse;
    public bool AsteroidAccelerates;
    private float AsteroidSpeed = 15.0f;

    public void Update()
    {
        //Make the player(asteroid) move in a certain time in the scene with the mouse, and the limits of his movement
            if (FollowMouse || Input.GetMouseButton(0))
            {
                _target = Camera.ScreenToWorldPoint(Input.mousePosition);
                _target.z = 0;
                _target.x = Mathf.Clamp(_target.x, -2.76f, 2.86f);
                _target.y = Mathf.Clamp(_target.y, -1.45f, 7.51f);
            }

            var delta = AsteroidSpeed * Time.deltaTime;
            if (AsteroidAccelerates)
            {
                delta *= Vector3.Distance(transform.position, _target);
            }

            transform.position = Vector3.MoveTowards(transform.position, _target, delta); 
    }
}