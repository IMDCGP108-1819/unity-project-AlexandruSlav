﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StartGame : MonoBehaviour
{
    public GameObject playerController;
    public GameObject gameoverPanel;
    public GameObject score;
    public GameObject gameController;
    public GameObject sguiggle;
    public PlayerController player;
    public GameObject instructions;

    private void Awake()
    { 
        //In the beggining of the scene only the Panel which has the title, the "Press P to play" and the "Press I for instructions" will be active
        sguiggle.SetActive(true);
        gameController.SetActive(false);
        gameoverPanel.SetActive(false);
        score.SetActive(false);
        player.GetComponent<PlayerController>().enabled = false;
        instructions.SetActive(false);
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.P))
        {
            //If the player presses "P", the Instuctions panel and the Start panel will not be active
            //If the player presses "P", the score, the game object(asteroid) and the Game Controller object will activate
            sguiggle.SetActive(false);
            score.SetActive(true);
            gameController.SetActive(true);
            player.GetComponent<PlayerController>().enabled = true;
            instructions.SetActive(false);
        }
        if (Input.GetKey(KeyCode.I))
        {
            //If the player presses "I", the Instructions panel will activate
            instructions.SetActive(true);
            sguiggle.SetActive(false);
        }
        if (playerController == null)
        {//If the game object(asteroid) is destroyed, then the Game Over Panel will activate
            gameoverPanel.SetActive(true);
        }
    }
}