﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotation : MonoBehaviour
{
    public float RotationSpeed = 75.0f;

    void Update()
    {
        //Make the game object(asteroid) rotate with a certain amount of speedness in a certain amount of time
        transform.Rotate(Vector3.forward * RotationSpeed * Time.deltaTime);  
    }
}